CREATE DATABASE supertokens;
CREATE DATABASE casbin;
CREATE DATABASE health_research;
